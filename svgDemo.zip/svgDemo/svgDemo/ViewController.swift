//
//  ViewController.swift
//  svgDemo
//
//  Created by Niketan on 31/07/19.
//  Copyright © 2019 Niketan. All rights reserved.
//

import UIKit
import SDWebImageSVGCoder

class ViewController: UIViewController {

    
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let url = URL.init(string: "https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/410.svg")
        
        let SVGCoder = SDImageSVGCoder.shared
        SDImageCodersManager.shared.addCoder(SVGCoder)
        imageView.sd_setImage(with: url)
        let SVGImageSize = CGSize(width: 100, height: 100)
        imageView.sd_setImage(with: url, placeholderImage: nil, options: [], context: [.svgImageSize : SVGImageSize])
        
    }


}

